#include "Player.h"

Player::Player()
{
	m_pos.x = 340;
	m_pos.y = 50;
	m_chess.Load("Pawn.png");
	
}

void Player::MoveChess()
{

	static bool leftchk = false;
	switch (m_ridder) {
	case UP:
		if (m_pos.y == -70 || m_pos.y == -40) break;
		else if (m_pos.y == 20) m_pos.y = -40;
		else m_pos.y -= 90;
		break;
	case DOWN:
		if (m_pos.y == 140) m_pos.y += 60;
		else if (m_pos.y == 560) break;
		else m_pos.y+= 90;
		break;
	case LEFT:
		if (m_pos.x == 70 || m_pos.x == 60) m_pos.x = 0;
		else if (m_pos.x == 0) break;
		else m_pos.x -= 90;
		break;
	case RIGHT:
		if (m_pos.x == 540 || m_pos.x == 520) m_pos.x = 600;
		else if (m_pos.x == 600) break;
		else m_pos.x += 90;
		break;
	default:
		break;

	}

}