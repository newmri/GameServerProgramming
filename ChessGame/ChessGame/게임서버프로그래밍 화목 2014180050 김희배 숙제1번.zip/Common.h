#pragma once

#include <Windows.h>
#include <atlimage.h>