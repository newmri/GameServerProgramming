#pragma once

#include "Common.h"
enum { UP = 0, DOWN, LEFT, RIGHT };

struct Player
{
	POINT m_pos;
	unsigned short m_ridder;
	CImage m_chess;
	Player();
	void MoveChess();
};